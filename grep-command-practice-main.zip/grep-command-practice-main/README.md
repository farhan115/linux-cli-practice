# GREP Command Practice Lab (Linux)

## 📌 Overview
This lab demonstrates hands-on practice with the Linux `grep` command, focusing on:

- Case-insensitive searches (`-i`)
- Recursive searches (`-r`)
- Inverted matching (`-v`)
- Combining multiple grep options

Practiced on **Kali Linux**, applicable to **Ubuntu / RHEL**.

---

## 📁 Lab Structure

